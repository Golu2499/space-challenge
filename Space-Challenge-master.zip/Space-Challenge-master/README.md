# Space-Challenge
Final Project for [Object Oriented Programming in Java](https://classroom.udacity.com/courses/ud283) course in Udacity.

The mission is to send a list of items (Habitats, bunkers, food supplies, and rovers) to Mars, but we need to run some simulations first to pick the correct fleet of rockets.
